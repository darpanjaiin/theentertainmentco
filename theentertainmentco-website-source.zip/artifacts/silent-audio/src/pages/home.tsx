import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion, useInView } from "framer-motion";
import { useRef, useState, useEffect } from "react";
import { ArrowRight, Check, ChevronRight, Battery, Radio, Music2, Zap, Smile, Volume2, MessageCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormMessage, FormLabel } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import logo from "@/assets/logo.png";
import heroEvent from "@/assets/hero-event.png";
import sangeetEvent from "@/assets/sangeet-event-night.png";
import corporateEvent from "@/assets/corporate-event-fun.png";
import headphonesProduct from "@/assets/headphones-product-blue.png";
import yogaEvent from "@/assets/yoga-event.png";
import movieEvent from "@/assets/movie-event-beanbag.png";
import houseParty from "@/assets/house-party-karaoke.png";

/* ─── Schemas ─────────────────────────────────────────────────────────────── */

const inquirySchema = z.object({
  name: z.string().min(2, "Name is required"),
  eventType: z.string().min(1, "Event type is required"),
  date: z.string().min(1, "Date is required"),
  phone: z.string().min(10, "Valid phone number is required"),
});

const contactSchema = z.object({
  name: z.string().min(2, "Name is required"),
  contact: z.string().min(1, "Phone or email is required"),
  eventType: z.string().min(1, "Event type is required"),
  city: z.string().min(1, "City is required"),
  date: z.string().min(1, "Date is required"),
  message: z.string().optional(),
});

/* ─── Motion helpers ──────────────────────────────────────────────────────── */

const fadeUp = {
  hidden: { opacity: 0, y: 32 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } },
};
const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.1 } },
};

function Reveal({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-60px" });
  return (
    <motion.div ref={ref} initial="hidden" animate={inView ? "visible" : "hidden"} variants={stagger} className={className}>
      {children}
    </motion.div>
  );
}

/* ─── Static data ─────────────────────────────────────────────────────────── */

const useCases = [
  { num: "01", title: "Weddings & Sangeet",    brief: "Keep the after-party alive past the 10 PM cutoff.",             bg: "bg-rose-50",    bar: "bg-rose-400",    text: "text-rose-700" },
  { num: "02", title: "College Events & Fests", brief: "Multiple DJ channels in one hall, zero sonic bleed.",          bg: "bg-blue-50",    bar: "bg-blue-400",    text: "text-blue-700" },
  { num: "03", title: "Corporate Offsites",     brief: "High-engagement audio in open resort environments.",           bg: "bg-emerald-50", bar: "bg-emerald-400", text: "text-emerald-700" },
  { num: "04", title: "House Parties",          brief: "Premium vibe in your own space. Zero neighbour complaints.",   bg: "bg-orange-50",  bar: "bg-orange-400",  text: "text-orange-700" },
  { num: "05", title: "Residential (RWA)",      brief: "Society celebrations that run as long as you want them to.",   bg: "bg-amber-50",   bar: "bg-amber-400",   text: "text-amber-700" },
  { num: "06", title: "Yoga & Wellness",        brief: "Guided instruction for large outdoor groups, distraction-free.", bg: "bg-green-50",  bar: "bg-green-400",   text: "text-green-700" },
  { num: "07", title: "Open-air Movie Nights",  brief: "Full cinematic audio, outdoors, without disturbing a soul.",   bg: "bg-indigo-50",  bar: "bg-indigo-400",  text: "text-indigo-700" },
  { num: "08", title: "Luxury Retreats",        brief: "Immersive audio that respects the silence around it.",         bg: "bg-purple-50",  bar: "bg-purple-400",  text: "text-purple-700" },
];

const steps = [
  { num: "01", title: "Inquire",         body: "Fill in the quick form with your event date, type, and guest count. Takes under a minute." },
  { num: "02", title: "We reach out",    body: "Our team gets back to you within 24 hours to understand your event and put together a custom quote." },
  { num: "03", title: "Plug in. Enjoy.", body: "We handle the full setup before your guests arrive. Headphones go on, the music plays, and the night goes as long as you want it to." },
];


const productFeatures = [
  { icon: Battery,  title: "~8 Hour Battery",           body: "Each headset lasts a full event on a single charge. No recharging mid-night." },
  { icon: Radio,    title: "250m Wireless Range",      body: "Transmitters blanket any venue size. Courtyards, resorts, open terraces. Full coverage." },
  { icon: Music2,   title: "3 Simultaneous Channels",  body: "Run multiple DJs, playlists, or languages at once. Guests choose their own channel." },
  { icon: Zap,      title: "Zero Audio Lag",           body: "Crystal-clear digital sync in real time. No echo, no delay, no static." },
  { icon: Smile,    title: "Feather-light Comfort",    body: "Adjustable, padded headsets designed for all-night wear. Fits every head size." },
  { icon: Volume2,  title: "Studio-grade Isolation",   body: "Guests control their own volume. Outsiders hear nothing. Literally nothing." },
];

const services = [
  {
    tag: "Self-managed",
    title: "Equipment Rental",
    desc: "The hardware only. Perfect if you have your own team to manage distribution.",
    includes: ["Wireless headset fleet", "FM transmitter setup", "Delivery and collection", "Technical setup guide"],
    cta: "Rent equipment",
  },
  {
    tag: "Most popular",
    title: "Managed Experience",
    desc: "We bring the gear and our crew handles everything — setup to shutdown.",
    includes: ["Everything in Equipment Rental", "On-site setup crew", "Guest distribution team", "Hygiene-managed headset handling"],
    cta: "Book managed",
    highlight: true,
  },
  {
    tag: "Full production",
    title: "Complete Package",
    desc: "End-to-end silent event production including DJ coordination and live channel management.",
    includes: ["Everything in Managed Experience", "DJ / playlist coordination", "Live channel switching", "Event timeline management"],
    cta: "Book full package",
  },
];

const CONTACT_EMAIL = "hello@theentertainmentco.in";
const WHATSAPP_NUM  = "918830093336";

/* ─── Select options (reused in both forms) ──────────────────────────────── */

function EventOptions() {
  return (
    <>
      <SelectItem value="wedding">Wedding &amp; Sangeet</SelectItem>
      <SelectItem value="houseparty">House Party</SelectItem>
      <SelectItem value="college">College Fest</SelectItem>
      <SelectItem value="corporate">Corporate Offsite</SelectItem>
      <SelectItem value="yoga">Yoga &amp; Wellness</SelectItem>
      <SelectItem value="movie">Open-air Movie Night</SelectItem>
      <SelectItem value="rwa">Residential (RWA)</SelectItem>
      <SelectItem value="retreat">Luxury Retreat</SelectItem>
      <SelectItem value="other">Other</SelectItem>
    </>
  );
}

/* ─── Hero inquiry form ───────────────────────────────────────────────────── */

function HeroInquiryForm() {
  const { toast } = useToast();
  const form = useForm<z.infer<typeof inquirySchema>>({
    resolver: zodResolver(inquirySchema),
    defaultValues: { name: "", eventType: "", date: "", phone: "" },
  });

  const onSubmit = (v: z.infer<typeof inquirySchema>) => {
    const subject = encodeURIComponent(`Event Inquiry - ${v.eventType}`);
    const body = encodeURIComponent(`Name: ${v.name}\nPhone: ${v.phone}\nEvent Type: ${v.eventType}\nDate: ${v.date}`);
    window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
    toast({ title: "Opening your email...", description: "Inquiry details are pre-filled and ready to send." });
    form.reset();
  };

  const inputCls = "h-11 rounded-xl border border-foreground/12 bg-white px-4 text-sm font-sans placeholder:text-foreground/35 focus-visible:ring-1 focus-visible:ring-foreground/30 focus-visible:border-foreground/30 transition-all";
  const selectCls = "h-11 rounded-xl border border-foreground/12 bg-white px-4 text-sm font-sans focus:ring-1 transition-all data-[placeholder]:text-foreground/35";

  return (
    <div className="bg-white rounded-2xl border border-foreground/8 shadow-md p-6 w-full" data-testid="form-hero-container">
      <p className="font-sans text-sm font-semibold text-foreground mb-5">Check your date</p>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3" data-testid="form-hero">
          <FormField control={form.control} name="name" render={({ field }) => (
            <FormItem>
              <FormControl><Input placeholder="Your name" {...field} className={inputCls} data-testid="input-hero-name" /></FormControl>
              <FormMessage className="text-xs" />
            </FormItem>
          )} />
          <FormField control={form.control} name="eventType" render={({ field }) => (
            <FormItem>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger className={selectCls} data-testid="select-hero-event"><SelectValue placeholder="Event type" /></SelectTrigger>
                </FormControl>
                <SelectContent><EventOptions /></SelectContent>
              </Select>
              <FormMessage className="text-xs" />
            </FormItem>
          )} />
          <div className="grid grid-cols-2 gap-3">
            <FormField control={form.control} name="date" render={({ field }) => (
              <FormItem>
                <FormControl><Input type="date" {...field} className={inputCls} data-testid="input-hero-date" /></FormControl>
                <FormMessage className="text-xs" />
              </FormItem>
            )} />
            <FormField control={form.control} name="phone" render={({ field }) => (
              <FormItem>
                <FormControl><Input placeholder="+91 phone" type="tel" {...field} className={inputCls} data-testid="input-hero-phone" /></FormControl>
                <FormMessage className="text-xs" />
              </FormItem>
            )} />
          </div>
          <Button type="submit" className="w-full h-11 rounded-xl bg-foreground text-background font-sans font-semibold text-sm hover:bg-foreground/85 transition-colors" data-testid="button-hero-submit">
            Check availability
          </Button>
        </form>
      </Form>
    </div>
  );
}

/* ─── Contact form ────────────────────────────────────────────────────────── */

function ContactForm() {
  const { toast } = useToast();
  const form = useForm<z.infer<typeof contactSchema>>({
    resolver: zodResolver(contactSchema),
    defaultValues: { name: "", contact: "", eventType: "", city: "", date: "", message: "" },
  });

  const onSubmit = (v: z.infer<typeof contactSchema>) => {
    const subject = encodeURIComponent(`Event Inquiry - ${v.eventType} - ${v.city}`);
    const body = encodeURIComponent(
      `Name: ${v.name}\nPhone / Email: ${v.contact}\nEvent Type: ${v.eventType}\nCity: ${v.city}\nDate: ${v.date}\n\nMessage:\n${v.message || "No additional message"}`
    );
    window.location.href = `mailto:${CONTACT_EMAIL}?subject=${subject}&body=${body}`;
    toast({ title: "Opening your email client...", description: "Your inquiry is pre-filled and ready to send to our team." });
    form.reset();
  };

  const inputCls = "h-12 rounded-xl border border-foreground/12 bg-white px-4 font-sans text-sm placeholder:text-foreground/35 focus-visible:ring-1 focus-visible:ring-foreground/30 focus-visible:border-foreground/30 transition-all";
  const selectCls = "h-12 rounded-xl border border-foreground/12 bg-white px-4 font-sans text-sm focus:ring-1 transition-all data-[placeholder]:text-foreground/35";
  const labelCls = "font-sans text-xs font-medium text-foreground/50 mb-1.5";

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5" data-testid="form-contact">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <FormField control={form.control} name="name" render={({ field }) => (
            <FormItem>
              <FormLabel className={labelCls}>Your name</FormLabel>
              <FormControl><Input placeholder="Ranveer Singh" {...field} className={inputCls} data-testid="input-contact-name" /></FormControl>
              <FormMessage className="text-xs" />
            </FormItem>
          )} />
          <FormField control={form.control} name="contact" render={({ field }) => (
            <FormItem>
              <FormLabel className={labelCls}>Phone or email</FormLabel>
              <FormControl><Input placeholder="+91 98765 43210 or you@email.com" {...field} className={inputCls} data-testid="input-contact-contact" /></FormControl>
              <FormMessage className="text-xs" />
            </FormItem>
          )} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <FormField control={form.control} name="eventType" render={({ field }) => (
            <FormItem>
              <FormLabel className={labelCls}>Event type</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger className={selectCls} data-testid="select-contact-event"><SelectValue placeholder="Select type" /></SelectTrigger>
                </FormControl>
                <SelectContent><EventOptions /></SelectContent>
              </Select>
              <FormMessage className="text-xs" />
            </FormItem>
          )} />
          <FormField control={form.control} name="city" render={({ field }) => (
            <FormItem>
              <FormLabel className={labelCls}>City</FormLabel>
              <FormControl><Input placeholder="Pune" {...field} className={inputCls} data-testid="input-contact-city" /></FormControl>
              <FormMessage className="text-xs" />
            </FormItem>
          )} />
        </div>
        <FormField control={form.control} name="date" render={({ field }) => (
          <FormItem>
            <FormLabel className={labelCls}>Event date</FormLabel>
            <FormControl><Input type="date" {...field} className={inputCls} data-testid="input-contact-date" /></FormControl>
            <FormMessage className="text-xs" />
          </FormItem>
        )} />
        <FormField control={form.control} name="message" render={({ field }) => (
          <FormItem>
            <FormLabel className={labelCls}>Tell us about your event</FormLabel>
            <FormControl>
              <Textarea
                placeholder="Guest count, venue type, anything else we should know..."
                {...field}
                className="rounded-xl border border-foreground/12 bg-white px-4 py-3 font-sans text-sm placeholder:text-foreground/35 focus-visible:ring-1 focus-visible:ring-foreground/30 focus-visible:border-foreground/30 min-h-[110px] resize-none transition-all"
                data-testid="input-contact-message"
              />
            </FormControl>
            <FormMessage className="text-xs" />
          </FormItem>
        )} />
        <Button type="submit" size="lg" className="w-full h-12 rounded-full bg-foreground text-background font-sans font-semibold tracking-wide hover:bg-foreground/85 transition-colors" data-testid="button-contact-submit">
          Send inquiry <ArrowRight size={16} className="ml-2" />
        </Button>
      </form>
    </Form>
  );
}

/* ─── Page ────────────────────────────────────────────────────────────────── */

export default function Home() {
  const [navScrolled, setNavScrolled] = useState(false);
  useEffect(() => {
    const fn = () => setNavScrolled(window.scrollY > 40);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-amber-200 selection:text-foreground">

      {/* ── Nav ─────────────────────────────────────────────────────────── */}
      <header className={`fixed top-0 inset-x-0 z-50 transition-all duration-400 ${navScrolled ? "bg-white/90 backdrop-blur-md border-b border-foreground/6 shadow-sm" : "bg-transparent"}`}>
        <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">
          <a href="/" className="flex items-center gap-2.5" data-testid="nav-brand">
            <img src={logo} alt="The Entertainment Co." className="w-12 h-12 object-contain" />
            <span className="font-extrabold text-sm text-foreground tracking-tight">The Entertainment Co.</span>
          </a>
          <nav className="hidden md:flex items-center gap-7">
            <a href="#use-cases" className="font-sans text-sm text-foreground/55 hover:text-foreground transition-colors">Events</a>
            <a href="#services" className="font-sans text-sm text-foreground/55 hover:text-foreground transition-colors">Services</a>
            <a href="#how" className="font-sans text-sm text-foreground/55 hover:text-foreground transition-colors">How it works</a>
          </nav>
          <a href="#inquire" className="inline-flex items-center gap-1.5 bg-foreground text-background font-sans text-sm font-medium px-5 py-2.5 rounded-full hover:bg-foreground/85 transition-colors" data-testid="nav-cta">
            Get a quote <ChevronRight size={14} />
          </a>
        </div>
      </header>

      {/* ── Hero ────────────────────────────────────────────────────────── */}
      <section className="relative pt-28 pb-16 md:pt-32 md:pb-24 overflow-hidden" data-testid="section-hero">
        <div className="absolute inset-0 bg-gradient-to-br from-amber-50/60 via-white to-white pointer-events-none" />
        <div className="relative max-w-6xl mx-auto px-6 grid lg:grid-cols-2 gap-14 lg:gap-10 items-center">

          {/* Left */}
          <motion.div initial="hidden" animate="visible" variants={stagger} className="flex flex-col gap-6 max-w-xl">
            <motion.h1 variants={fadeUp} className="text-[clamp(2.8rem,6.5vw,5rem)] leading-[1.05] font-extrabold text-foreground tracking-tight">
              The party doesn't stop<br />at <span className="text-highlight">10&nbsp;PM.</span>
            </motion.h1>
            <motion.p variants={fadeUp} className="font-sans text-lg text-foreground/55 leading-relaxed">
              Professional silent audio experiences for weddings, sangeet nights, fests, and corporate offsites. Your event continues, neighbours hear nothing.
            </motion.p>
            <motion.div variants={fadeUp} className="flex flex-wrap gap-3 items-center pt-1">
              <a href="#inquire" className="inline-flex items-center gap-2 bg-foreground text-background font-sans font-semibold text-base px-7 py-3.5 rounded-full hover:bg-foreground/85 transition-colors" data-testid="cta-primary">
                Check availability <ArrowRight size={16} />
              </a>
              <a href="#how" className="inline-flex items-center gap-2 border border-foreground/20 text-foreground font-sans font-medium text-base px-6 py-3.5 rounded-full hover:border-foreground/50 transition-colors" data-testid="cta-secondary">
                See how it works
              </a>
            </motion.div>
            <motion.div variants={fadeUp} className="flex flex-wrap items-center gap-2 pt-2">
              {["Weddings", "Sangeet", "Corporate", "House Parties", "College Fests"].map((b) => (
                <span key={b} className="font-sans text-xs font-medium text-foreground/45 bg-foreground/5 border border-foreground/8 px-3 py-1.5 rounded-full">{b}</span>
              ))}
            </motion.div>
          </motion.div>

          {/* Right */}
          <motion.div initial={{ opacity: 0, x: 32 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, delay: 0.3, ease: [0.16, 1, 0.3, 1] }} className="flex flex-col gap-4">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl aspect-[4/5] max-h-[500px]">
              <img src={heroEvent} alt="Silent audio at a premium Indian event" className="w-full h-full object-cover" data-testid="img-hero" />
              <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-sm rounded-2xl p-3.5 flex items-center gap-3 shadow-lg">
                <img src={logo} alt="" className="w-12 h-12 object-contain shrink-0" />
                <div>
                  <p className="font-sans text-sm font-semibold text-foreground leading-tight">Silent. Seamless. Premium.</p>
                  <p className="font-sans text-xs text-foreground/45 mt-0.5">Silent audio specialists</p>
                </div>
                <div className="ml-auto flex items-center gap-1">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="font-sans text-xs text-foreground/45">Available</span>
                </div>
              </div>
            </div>
            <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7, delay: 0.6 }}>
              <HeroInquiryForm />
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ── Problem / Stats ──────────────────────────────────────────────── */}
      <section className="py-24 md:py-36" data-testid="section-problem">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal>
            <motion.div variants={fadeUp} className="max-w-3xl mx-auto text-center">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-foreground/35 mb-5">The problem</p>
              <h2 className="text-[clamp(2.2rem,4.5vw,3.6rem)] font-extrabold leading-[1.1] text-foreground tracking-tight mb-6">
                Where others stop,{" "}
                <span className="text-highlight">we keep<br />the night going.</span>
              </h2>
              <p className="font-sans text-lg text-foreground/55 leading-relaxed mb-5">
                Indian events are defined by energy. But noise restrictions and RWA pressure create a hard 10 PM cutoff. Events end early, or never happen at all. The Entertainment Co. resolves this.
              </p>
              <p className="font-sans text-base text-foreground/40 leading-relaxed">
                We deliver professional-grade audio through wireless headphones. Guests hear everything at full quality. The surrounding environment stays completely silent.
              </p>
            </motion.div>
          </Reveal>
        </div>
      </section>

      {/* ── Use Cases ───────────────────────────────────────────────────── */}
      <section id="use-cases" className="py-24 md:py-36 bg-foreground/[0.015] border-y border-foreground/8" data-testid="section-use-cases">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal>
            <motion.div variants={fadeUp} className="mb-14">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-foreground/35 mb-4">Where it works</p>
              <h2 className="text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-tight text-foreground">Every event. Uninterrupted.</h2>
            </motion.div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {useCases.map((uc, i) => (
                <motion.div key={i} variants={fadeUp} className={`card-hover rounded-2xl overflow-hidden border border-foreground/8 ${uc.bg}`} data-testid={`card-use-case-${i}`}>
                  <div className={`h-1.5 w-full ${uc.bar}`} />
                  <div className="p-5">
                    <span className={`font-sans text-[10px] font-bold tracking-[0.18em] uppercase ${uc.text} mb-3 block`}>{uc.num}</span>
                    <h3 className="font-extrabold text-base text-foreground leading-snug mb-2">{uc.title}</h3>
                    <p className="font-sans text-sm text-foreground/50 leading-relaxed">{uc.brief}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── How It Works ────────────────────────────────────────────────── */}
      <section id="how" className="py-24 md:py-36" data-testid="section-how">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal>
            <motion.div variants={fadeUp} className="mb-16 max-w-xl">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-foreground/35 mb-4">How it works</p>
              <h2 className="text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-tight text-foreground">Three steps. Zero friction.</h2>
            </motion.div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {steps.map((s, i) => (
                <motion.div key={i} variants={fadeUp} className="relative z-10">
                  <div className="w-14 h-14 rounded-2xl bg-foreground flex items-center justify-center mb-5">
                    <span className="font-extrabold text-background text-base">{s.num}</span>
                  </div>
                  <h3 className="font-extrabold text-lg text-foreground mb-2">{s.title}</h3>
                  <p className="font-sans text-sm text-foreground/50 leading-relaxed">{s.body}</p>
                </motion.div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── Feature: Sangeet ────────────────────────────────────────────── */}
      <section className="py-24 md:py-36 bg-foreground/[0.015] border-y border-foreground/8" data-testid="section-feature-sangeet">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal className="grid lg:grid-cols-2 gap-14 items-center">
            <motion.div variants={fadeUp} className="rounded-3xl overflow-hidden shadow-xl aspect-[16/10]">
              <img src={sangeetEvent} alt="Silent sangeet wedding experience" className="w-full h-full object-cover" data-testid="img-sangeet" />
            </motion.div>
            <motion.div variants={fadeUp} className="flex flex-col gap-6">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-foreground/35">Weddings</p>
              <h2 className="text-[clamp(1.8rem,3.5vw,3rem)] font-extrabold leading-[1.1] tracking-tight text-foreground">
                The sangeet doesn't have to end at <span className="text-highlight">10 PM.</span>
              </h2>
              <p className="font-sans text-base text-foreground/55 leading-relaxed">
                The most memorable moments happen after midnight. Wireless headphones mean your guests dance all night, your venue stays compliant, and not a single neighbour files a complaint.
              </p>
              {["Extends your event without any time constraints", "Guests control their own volume", "Quick setup — gear ready before your first guest walks in"].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center shrink-0">
                    <Check size={12} className="text-green-600 stroke-[2.5]" />
                  </div>
                  <span className="font-sans text-sm text-foreground/65 font-medium">{item}</span>
                </div>
              ))}
              <a href="#inquire" className="inline-flex items-center gap-2 bg-foreground text-background font-sans font-semibold text-sm px-6 py-3 rounded-full hover:bg-foreground/85 transition-colors w-fit" data-testid="cta-wedding">
                Book for your wedding <ArrowRight size={15} />
              </a>
            </motion.div>
          </Reveal>
        </div>
      </section>

      {/* ── Feature: Corporate ──────────────────────────────────────────── */}
      <section className="py-24 md:py-36" data-testid="section-feature-corporate">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal className="grid lg:grid-cols-2 gap-14 items-center">
            <motion.div variants={fadeUp} className="order-2 lg:order-1 flex flex-col gap-6">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-foreground/35">Corporate</p>
              <h2 className="text-[clamp(1.8rem,3.5vw,3rem)] font-extrabold leading-[1.1] tracking-tight text-foreground">
                Engagement that scales to any <span className="text-highlight">environment.</span>
              </h2>
              <p className="font-sans text-base text-foreground/55 leading-relaxed">
                Resort offsites, team offsites, leadership retreats. Silent audio lets you run multiple parallel tracks, keynotes, and group activities without acoustic compromise.
              </p>
              {["Multiple simultaneous audio channels", "Works outdoors and in open venues", "Professional setup and crew included"].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-blue-100 flex items-center justify-center shrink-0">
                    <Check size={12} className="text-blue-600 stroke-[2.5]" />
                  </div>
                  <span className="font-sans text-sm text-foreground/65 font-medium">{item}</span>
                </div>
              ))}
              <a href="#inquire" className="inline-flex items-center gap-2 bg-foreground text-background font-sans font-semibold text-sm px-6 py-3 rounded-full hover:bg-foreground/85 transition-colors w-fit" data-testid="cta-corporate">
                Plan your offsite <ArrowRight size={15} />
              </a>
            </motion.div>
            <motion.div variants={fadeUp} className="order-1 lg:order-2 rounded-3xl overflow-hidden shadow-xl aspect-[4/3]">
              <img src={corporateEvent} alt="Corporate offsite with silent audio" className="w-full h-full object-cover" data-testid="img-corporate" />
            </motion.div>
          </Reveal>
        </div>
      </section>

      {/* ── Feature: House Party ─────────────────────────────────────────── */}
      <section className="py-24 md:py-36 bg-foreground/[0.015] border-y border-foreground/8" data-testid="section-feature-house">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal className="grid lg:grid-cols-2 gap-14 items-center">
            <motion.div variants={fadeUp} className="rounded-3xl overflow-hidden shadow-xl aspect-[16/10]">
              <img src={houseParty} alt="Silent house party experience" className="w-full h-full object-cover" data-testid="img-house" />
            </motion.div>
            <motion.div variants={fadeUp} className="flex flex-col gap-6">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-foreground/35">House Parties</p>
              <h2 className="text-[clamp(1.8rem,3.5vw,3rem)] font-extrabold leading-[1.1] tracking-tight text-foreground">
                Your space. Your vibe. <span className="text-highlight">Your rules.</span>
              </h2>
              <p className="font-sans text-base text-foreground/55 leading-relaxed">
                Not everyone is comfortable dancing in crowded bars or venues with open bars around them. Silent audio lets you host a premium dance experience in your own home or apartment. Your guests dance, laugh, and connect, entirely on your terms.
              </p>
              {["No venue curfew, no social awkwardness", "Apartment-friendly, society-safe", "Dance at 2 AM without a single complaint"].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-orange-100 flex items-center justify-center shrink-0">
                    <Check size={12} className="text-orange-600 stroke-[2.5]" />
                  </div>
                  <span className="font-sans text-sm text-foreground/65 font-medium">{item}</span>
                </div>
              ))}
              <a href="#inquire" className="inline-flex items-center gap-2 bg-foreground text-background font-sans font-semibold text-sm px-6 py-3 rounded-full hover:bg-foreground/85 transition-colors w-fit" data-testid="cta-house">
                Plan your house party <ArrowRight size={15} />
              </a>
            </motion.div>
          </Reveal>
        </div>
      </section>

      {/* ── Feature: Yoga + Movie ────────────────────────────────────────── */}
      <section className="py-24 md:py-36" data-testid="section-feature-misc">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal>
            <motion.div variants={fadeUp} className="text-center mb-14 max-w-2xl mx-auto">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-foreground/35 mb-4">More experiences</p>
              <h2 className="text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-tight text-foreground">
                Quiet outside. <span className="text-highlight">Electric inside.</span>
              </h2>
            </motion.div>
            <div className="grid md:grid-cols-2 gap-6">
              <motion.div variants={fadeUp} className="rounded-3xl overflow-hidden shadow-md aspect-[4/3] relative group">
                <img src={yogaEvent} alt="Outdoor yoga with silent audio" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" data-testid="img-yoga" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <span className="font-sans text-xs font-bold tracking-[0.15em] uppercase text-white/60 mb-1 block">Yoga &amp; Wellness</span>
                  <p className="font-extrabold text-xl text-white leading-snug">Guided sessions for 200+, outdoors, crystal clear.</p>
                </div>
              </motion.div>
              <motion.div variants={fadeUp} className="rounded-3xl overflow-hidden shadow-md aspect-[4/3] relative group">
                <img src={movieEvent} alt="Open air movie screening" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" data-testid="img-movie" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <span className="font-sans text-xs font-bold tracking-[0.15em] uppercase text-white/60 mb-1 block">Open-air Movie Nights</span>
                  <p className="font-extrabold text-xl text-white leading-snug">Full cinematic audio in open air, zero PA noise.</p>
                </div>
              </motion.div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── Product Features ─────────────────────────────────────────────── */}
      <section className="py-24 md:py-36 bg-foreground/[0.015] border-y border-foreground/8" data-testid="section-product">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal>
            <motion.div variants={fadeUp} className="mb-14">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-foreground/35 mb-4">The hardware</p>
              <h2 className="text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-tight text-foreground max-w-xl">
                Built for events. <span className="text-highlight">Built to last.</span>
              </h2>
            </motion.div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-14">
              {productFeatures.map((f, i) => (
                <motion.div key={i} variants={fadeUp} className="bg-white border border-foreground/8 rounded-2xl p-6 card-hover">
                  <div className="w-10 h-10 bg-foreground/5 rounded-xl flex items-center justify-center mb-4">
                    <f.icon size={20} className="text-foreground/70" strokeWidth={1.8} />
                  </div>
                  <h3 className="font-extrabold text-base text-foreground mb-1.5">{f.title}</h3>
                  <p className="font-sans text-sm text-foreground/50 leading-relaxed">{f.body}</p>
                </motion.div>
              ))}
            </div>
            <motion.div variants={fadeUp} className="rounded-3xl overflow-hidden shadow-xl aspect-[16/7]">
              <img src={headphonesProduct} alt="Premium wireless headphones" className="w-full h-full object-cover" data-testid="img-headphones" />
            </motion.div>
          </Reveal>
        </div>
      </section>

      {/* ── Services ─────────────────────────────────────────────────────── */}
      <section id="services" className="py-24 md:py-36" data-testid="section-services">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal>
            <motion.div variants={fadeUp} className="mb-14">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-foreground/35 mb-4">What we offer</p>
              <h2 className="text-[clamp(2rem,4vw,3.2rem)] font-extrabold leading-[1.1] tracking-tight text-foreground max-w-xl">
                Pick your <span className="text-highlight">experience level.</span>
              </h2>
            </motion.div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {services.map((s, i) => (
                <motion.div key={i} variants={fadeUp} className={`rounded-3xl p-7 flex flex-col gap-5 border ${s.highlight ? "bg-foreground text-background border-foreground" : "bg-white border-foreground/8"}`}>
                  <div>
                    <span className={`font-sans text-[10px] font-bold tracking-[0.18em] uppercase ${s.highlight ? "text-background/50" : "text-foreground/35"} mb-3 block`}>{s.tag}</span>
                    <h3 className={`font-extrabold text-xl mb-2 ${s.highlight ? "text-background" : "text-foreground"}`}>{s.title}</h3>
                    <p className={`font-sans text-sm leading-relaxed ${s.highlight ? "text-background/65" : "text-foreground/50"}`}>{s.desc}</p>
                  </div>
                  <ul className="space-y-2.5 flex-1">
                    {s.includes.map((item, j) => (
                      <li key={j} className="flex items-start gap-2.5">
                        <div className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${s.highlight ? "bg-white/15" : "bg-green-100"}`}>
                          <Check size={10} className={s.highlight ? "text-background stroke-[2.5]" : "text-green-600 stroke-[2.5]"} />
                        </div>
                        <span className={`font-sans text-sm ${s.highlight ? "text-background/75" : "text-foreground/60"}`}>{item}</span>
                      </li>
                    ))}
                  </ul>
                  <a href="#inquire" className={`inline-flex items-center justify-center gap-2 font-sans font-semibold text-sm px-5 py-3 rounded-full transition-colors ${s.highlight ? "bg-white text-foreground hover:bg-white/90" : "bg-foreground text-background hover:bg-foreground/85"}`}>
                    {s.cta} <ArrowRight size={14} />
                  </a>
                </motion.div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── Why Silent Audio (dark) ───────────────────────────────────────── */}
      <section className="py-24 md:py-36 bg-foreground text-background" data-testid="section-why">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal>
            <motion.div variants={fadeUp} className="mb-14">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-background/35 mb-4">The case for silent audio</p>
              <h2 className="text-[clamp(2rem,4vw,3.4rem)] font-extrabold leading-[1.1] tracking-tight text-background max-w-2xl">
                The buyer is not just paying for headphones.
              </h2>
            </motion.div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {["Bypass venue time limits and local curfews.", "Zero risk of RWA or police complaints.", "Up to 3 simultaneous audio channels.", "Studio-quality isolation in any environment."].map((p, i) => (
                <motion.div key={i} variants={fadeUp} className="flex items-start gap-4 bg-white/5 border border-white/8 rounded-2xl p-6">
                  <div className="w-8 h-8 bg-white/10 rounded-xl flex items-center justify-center shrink-0 mt-0.5">
                    <Check size={16} className="text-background stroke-[2.5]" />
                  </div>
                  <p className="font-sans text-base text-background/80 leading-relaxed font-medium">{p}</p>
                </motion.div>
              ))}
            </div>
          </Reveal>
        </div>
      </section>

      {/* ── Inquiry Form ─────────────────────────────────────────────────── */}
      <section id="inquire" className="py-24 md:py-36" data-testid="section-contact">
        <div className="max-w-6xl mx-auto px-6">
          <Reveal className="grid lg:grid-cols-[1fr_560px] gap-16 items-start">
            <motion.div variants={fadeUp} className="lg:sticky lg:top-28">
              <p className="font-sans text-xs font-semibold tracking-[0.2em] uppercase text-foreground/35 mb-5">Get in touch</p>
              <h2 className="text-[clamp(2rem,4vw,3.4rem)] font-extrabold leading-[1.1] tracking-tight text-foreground mb-5">
                Tell us about your event.
              </h2>
              <p className="font-sans text-base text-foreground/50 leading-relaxed mb-8">
                We respond within 24 hours with a custom quote for your event.
              </p>
              {["No deposit to inquire", "Transparent per-event pricing"].map((t, i) => (
                <div key={i} className="flex items-center gap-3 mb-3">
                  <div className="w-5 h-5 rounded-full bg-amber-100 flex items-center justify-center shrink-0">
                    <Check size={11} className="text-amber-700 stroke-[2.5]" />
                  </div>
                  <span className="font-sans text-sm text-foreground/60 font-medium">{t}</span>
                </div>
              ))}
              <div className="mt-8 pt-8 border-t border-foreground/8 space-y-3">
                <p className="font-sans text-xs font-semibold tracking-[0.15em] uppercase text-foreground/30 mb-4">Reach us directly</p>
                <a href={`mailto:${CONTACT_EMAIL}`} className="flex items-center gap-2.5 font-sans text-sm text-foreground/55 hover:text-foreground transition-colors">
                  <div className="w-7 h-7 rounded-full bg-foreground/5 flex items-center justify-center"><ArrowRight size={13} /></div>
                  {CONTACT_EMAIL}
                </a>
                <a href={`https://wa.me/${WHATSAPP_NUM}?text=Hi, I'm interested in booking silent audio for my event.`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2.5 font-sans text-sm text-foreground/55 hover:text-foreground transition-colors">
                  <div className="w-7 h-7 rounded-full bg-green-100 flex items-center justify-center"><MessageCircle size={13} className="text-green-600" /></div>
                  WhatsApp us
                </a>
              </div>
            </motion.div>
            <motion.div variants={fadeUp}>
              <div className="bg-foreground/[0.02] border border-foreground/8 rounded-3xl p-8">
                <ContactForm />
              </div>
            </motion.div>
          </Reveal>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────────────────────────────── */}
      <footer className="border-t border-foreground/8 py-10" data-testid="footer">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-10">
            <div>
              <div className="flex items-center gap-2.5 mb-3">
                <img src={logo} alt="The Entertainment Co." className="w-10 h-10 object-contain" />
                <span className="font-extrabold text-sm text-foreground tracking-tight">The Entertainment Co.</span>
              </div>
              <p className="font-sans text-xs text-foreground/40 leading-relaxed max-w-[220px]">
                Silent audio experiences for events across India.
              </p>
            </div>
            <div>
              <p className="font-sans text-xs font-semibold tracking-[0.15em] uppercase text-foreground/30 mb-4">Events</p>
              <div className="grid grid-cols-2 gap-y-2">
                {useCases.slice(0, 6).map((uc, i) => <span key={i} className="font-sans text-xs text-foreground/45">{uc.title}</span>)}
              </div>
            </div>
            <div>
              <p className="font-sans text-xs font-semibold tracking-[0.15em] uppercase text-foreground/30 mb-4">Contact</p>
              <div className="space-y-2">
                <a href={`mailto:${CONTACT_EMAIL}`} className="font-sans text-xs text-foreground/45 hover:text-foreground transition-colors block">{CONTACT_EMAIL}</a>
                <a href={`https://wa.me/${WHATSAPP_NUM}`} target="_blank" rel="noopener noreferrer" className="font-sans text-xs text-foreground/45 hover:text-foreground transition-colors block">WhatsApp</a>
                <p className="font-sans text-xs text-foreground/45">India</p>
              </div>
            </div>
          </div>
          <div className="border-t border-foreground/8 pt-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <p className="font-sans text-xs text-foreground/30">&copy; {new Date().getFullYear()} The Entertainment Co. All rights reserved.</p>
            <p className="font-sans text-xs text-foreground/25">India</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
