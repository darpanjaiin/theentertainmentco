# The Entertainment Co | GitHub Pages deployment

This repository is prepared to host the existing React/Vite website at **https://theentertainmentco.in**. The server in `artifacts/api-server` is not needed for the current website: both inquiry forms use `mailto:` links, which open the visitor's email client and do not submit or store enquiries on a server.

## 1. Upload this project to the empty GitHub repository

Repository: https://github.com/darpanjaiin/theentertainmentco

Extract this ZIP to a folder. Open a terminal/PowerShell **inside that folder** (where `package.json` and `.github` appear) and run:

```sh
git init
git branch -M main
git add .
git commit -m "Deploy The Entertainment Co website"
git remote add origin https://github.com/darpanjaiin/theentertainmentco.git
git push -u origin main
```

If you are prompted to sign in, use GitHub authentication; never put a password or access token into the repository files. The repository was empty when this archive was made. If it is no longer empty, reconcile changes before pushing.

## 2. Enable GitHub Pages

Visit https://github.com/darpanjaiin/theentertainmentco/settings/pages

- Under **Build and deployment > Source**, select **GitHub Actions**.
- Under **Custom domain**, enter **theentertainmentco.in** and click **Save**. This step is required, even though the build files refer to the domain.
- Once DNS and the Pages certificate are ready, enable **Enforce HTTPS**.

Check the workflow at https://github.com/darpanjaiin/theentertainmentco/actions

## 3. Set domain DNS records at your domain registrar / DNS provider

Create or update these records for the apex/root domain:

| Type | Host | Value |
| ---- | ---- | ----- |
| A | @ | 185.199.108.153 |
| A | @ | 185.199.109.153 |
| A | @ | 185.199.110.153 |
| A | @ | 185.199.111.153 |
| CNAME | www | darpanjaiin.github.io |

Remove **conflicting** existing apex A/AAAA records and conflicting `www` CNAME/A records only after confirming they are obsolete. Do not delete MX, TXT, SPF, DKIM or other records used by email and external services. If your provider has a CNAME record for the root (`@`), remove it unless it is an intentional ALIAS/ANAME compatible with GitHub Pages.

These values are documented at https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site

DNS propagation can take up to 24 hours; certificate issuance can take additional time. Recheck the domain and the HTTPS checkbox in Pages settings.

## 4. Automatic deployments

Push to `main` to trigger `.github/workflows/deploy.yml`. It builds `@workspace/silent-audio` and deploys its `artifacts/silent-audio/dist/public` directory. No Vercel, Netlify, VPS, or paid hosting is required for this static website.

## Project notes

- Homepage entry: `artifacts/silent-audio/src/pages/home.tsx`.
- HTML/SEO metadata: `artifacts/silent-audio/index.html`.
- Vite config: `artifacts/silent-audio/vite.config.ts` with default site base `/`.
- Public favicon and Open Graph image are included.
- Contact forms are currently email-client handoffs (`mailto:`), not server-backed forms. Contact email is `hello@theentertainmentco.in`; ensure the mailbox is active before launch.
- The preview and production image assets remain in the source zip. No external API is required for the homepage.
- You can build locally with Node.js 22 and pnpm 10: `pnpm install --frozen-lockfile && pnpm --filter @workspace/silent-audio build`.

## Current access limitation

Preparing this archive does not modify the GitHub repository or DNS. Publishing requires authenticated GitHub access and DNS-provider access.
